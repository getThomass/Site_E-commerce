<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Panier</title>
	<link rel="stylesheet" type="text/css" href="Panier.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel= "stylesheet"
	href= "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
	<?php 
		try
		{
			$bdd = new PDO('mysql:host=localhost;dbname=projetpiscine;charset=utf8', 'root', '');
		}
		catch (Exception $e)
		{
		        die('Erreur : ' . $e->getMessage());
		}
		$reponse=$bdd->query('SELECT *
								FROM acheteur
								'
							) or die(print_r($bdd->errorInfo()));
		while($donnees=$reponse->fetch()){
			if($donnees["Email_ECE"]==$_GET["email"]){
				$id_acheteur=$donnees["ID_acheteur"];
			}
		}
		echo '<form method="POST" action="paiement.php">';
		$reponse->closeCursor();
		$reponse_2=$bdd->query("SELECT DISTINCT ID_article
								FROM panier
								WHERE ID_acheteur=$id_acheteur"
							) or die(print_r($bdd->errorInfo()));
		$prix_total=0.0;
		$i="0";
		while($donnees_2=$reponse_2->fetch()){
			$id_article=$donnees_2['ID_article'];
			$reponse_3=$bdd->query("SELECT *
									FROM article
									WHERE ID_article=$id_article")or die(print_r($bdd->errorInfo()));
			$reponse_4=$bdd->query("SELECT COUNT(*) as Quantite
									FROM panier
									WHERE ID_acheteur=$id_acheteur AND ID_article=$id_article")or die(print_r($bdd->errorInfo()));
			$quantite=$reponse_4->fetch();
			while($donnees_3=$reponse_3->fetch()){
				$id_vendeur=$donnees_3['ID_vendeur'];
				$reponse_5=$bdd->query("SELECT Nom_vendeur,Prenom_vendeur
										FROM vendeur 
										WHERE ID_vendeur=$id_vendeur")or die(print_r($bdd->errorInfo()));
				$nom=$reponse_5->fetch();
				echo '<div id="article">
						<div id="photo">
							<img src="http://localhost/Projet_piscine_complet/Photos_articles/'.$donnees_3["lien_photo_item"].'" height="115" width="115"/>
						</div>
						<div id="nom">
							Nom: '.$donnees_3["Nom_article"].
						'</div>
						<div id="quantite">
							Quantité: '.$quantite["Quantite"].
						'</div>
						<div id="description">
							Description: '.$donnees_3["Description"].
						"</div>
						<div id='prix'>
							Prix de l'article: ".$donnees_3["Prix"]."€".
						'</div>
						<div id="vendeur">
							Vendeur: '.$nom["Nom_vendeur"].' '.$nom["Prenom_vendeur"].
						"</div>";
				echo '<div id="boutton">';	
				if($donnees_3["Type_vente1"]==1){
					echo 	'<div id="achat_immediat">
								<input type="button" name="achat_immediat" value="Achat immédiat"/>
							</div>';
				}
				if($donnees_3["Type_vente2"]==1){
					echo 	'<div id="enchere">
								<input type="button" name="enchere" value="enchère"/>
							</div>';
				}
				if($donnees_3["Type_vente3"]==1){
					echo 	'<div id="meilleur_offre">
								<input type="button" name="meilleur_offre" value="Meilleur_offre"/>
							</div>';
				}
				echo '</div></div>';
				$prix_total=$prix_total+floatval($donnees_3["Prix"]);
			}
			$i=strval(intval($i)+1);
		}
		$reponse_2->closeCursor();
		echo '<input type="submit" name="validation" id="valider" value="Passer la commande"/>';
		echo '<div id="somme_total">Somme total: '.$prix_total."€".'</div>';
		echo '</form>'

	?>
</body>
</html>