<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bravo</title>
</head>
<body>
	<h1>Félicitation vous avez ajouté un vendeur</h1>
</body>
</html>